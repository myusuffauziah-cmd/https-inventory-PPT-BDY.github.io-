import os
import re
import sqlite3
import pandas as pd

# =====================================================
# LOKASI FILE STOCK
# =====================================================

STOCK_FOLDER = r"G:\Shared drives\01 Pilar Informasi Umum\01-05 Sparepart Dept\Stock Sparepart\Stock PPT"

stock_file = os.path.join(
    STOCK_FOLDER,
    "Daily Stock PPT ALL Cabang 2026.xlsx"
)

# =====================================================
# LOKASI FILE ITC
# =====================================================

ITC_FOLDER = r"G:\.shortcut-targets-by-id\12unMNWou5vWOR2R53EvYBmPYEGdOlfl6\01-05 Sparepart Dept\Part List\File ITC"

itc_file = os.path.join(
    ITC_FOLDER,
    "{DLR} Interchange Part Numbers_April 2026.xlsx"
)

# =====================================================
# CEK FILE
# =====================================================

if not os.path.exists(stock_file):
    raise FileNotFoundError(stock_file)

if not os.path.exists(itc_file):
    raise FileNotFoundError(itc_file)

print("=" * 60)
print("MENGGUNAKAN FILE")
print("=" * 60)
print(stock_file)
print(itc_file)
print("=" * 60)

# =====================================================
# DATABASE SQLITE
# =====================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

database_folder = os.path.join(
    BASE_DIR,
    "database"
)

os.makedirs(
    database_folder,
    exist_ok=True
)

database_file = os.path.join(
    database_folder,
    "database.db"
)

# =====================================================
# MEMBACA SHEET INVENTORY
# =====================================================

inventory = pd.read_excel(
    stock_file,
    sheet_name="Inventory per Gudang",
    header=1
)

inventory.columns = inventory.columns.str.strip()

print("\nKolom Inventory")
print(inventory.columns.tolist())

# =====================================================
# FUNGSI UBAH NAMA KOLOM
# =====================================================

def clean_column(col):

    col = str(col)

    col = col.lower()

    col = col.replace("gd.", "gd_")
    col = col.replace("gd-", "gd_")
    col = col.replace("gd ", "gd_")

    col = col.replace("pos-", "pos_")
    col = col.replace("pos ", "pos_")

    col = col.replace("/", "_")
    col = col.replace("-", "_")
    col = col.replace(".", "_")
    col = col.replace("(", "_")
    col = col.replace(")", "_")

    col = col.replace("__", "_")

    col = re.sub(
        r'[^a-z0-9_]',
        '',
        col
    )

    while "__" in col:
        col = col.replace("__", "_")

    return col.strip("_")

# =====================================================
# RENAME OTOMATIS
# =====================================================

rename_dict = {}

for col in inventory.columns:

    new_name = clean_column(col)

    # -----------------------------
    # Kolom utama
    # -----------------------------

    if new_name == "itemcode":
        new_name = "item_code"

    elif new_name == "itemname":
        new_name = "item_name"

    elif new_name == "totalallgd":
        new_name = "total_all"

    elif new_name == "transit":
        new_name = "transit"

    rename_dict[col] = new_name

inventory.rename(
    columns=rename_dict,
    inplace=True
)

print("\nKolom Baru")
print(inventory.columns.tolist())
# =====================================================
# AMBIL KOLOM YANG DIPERLUKAN
# =====================================================

# Kolom utama
main_columns = [
    "item_code",
    "item_name",
    "total_all"
]

# Semua kolom gudang otomatis
gudang_columns = []

for col in inventory.columns:

    if col.startswith("gd_"):
        gudang_columns.append(col)

# Transit jika ada
if "transit" in inventory.columns:
    gudang_columns.append("transit")

# Gabungkan semua kolom
selected_columns = []

for col in main_columns:

    if col in inventory.columns:
        selected_columns.append(col)

selected_columns.extend(gudang_columns)

inventory = inventory[selected_columns]

# =====================================================
# UBAH NAMA TOTAL
# =====================================================



# =====================================================
# BERSIHKAN DATA INVENTORY
# =====================================================

inventory = inventory.dropna(
    subset=["item_code"]
)

inventory["item_code"] = (
    inventory["item_code"]
    .astype(str)
    .str.strip()
)

inventory["item_name"] = (
    inventory["item_name"]
    .fillna("")
    .astype(str)
    .str.strip()
)

# Semua kolom gudang menjadi angka

for col in inventory.columns:

    if col in ["item_code", "item_name"]:
        continue

    inventory[col] = (
        pd.to_numeric(
            inventory[col],
            errors="coerce"
        )
        .fillna(0)
        .astype(int)
    )

print("\nJumlah Item Inventory :", len(inventory))

# =====================================================
# MEMBACA FILE ITC
# =====================================================

print("\nMembaca File ITC...")

itc = pd.read_excel(
    itc_file,
    sheet_name="interchange"
)

itc.columns = itc.columns.str.strip()

print(itc.columns.tolist())

# =====================================================
# AMBIL KOLOM ITC
# =====================================================

itc = itc[
    [
        "Parts Number",
        "Interchange"
    ]
]

itc.rename(
    columns={
        "Parts Number": "item_code",
        "Interchange": "itc"
    },
    inplace=True
)

itc["item_code"] = (
    itc["item_code"]
    .fillna("")
    .astype(str)
    .str.strip()
)

itc["itc"] = (
    itc["itc"]
    .fillna("")
    .astype(str)
    .str.strip()
)

# Hilangkan duplikat

itc = itc.drop_duplicates(
    subset=["item_code"]
)

print("Jumlah ITC :", len(itc))

# =====================================================
# GABUNGKAN INVENTORY + ITC
# =====================================================

df = inventory.merge(
    itc,
    on="item_code",
    how="left"
)

df["itc"] = df["itc"].fillna("")

print("\nJumlah Setelah Merge :", len(df))
# =====================================================
# BERSIHKAN DATA AKHIR
# =====================================================

df = df[df["item_code"] != ""]

df = df.drop_duplicates(
    subset=["item_code"]
)

df.reset_index(
    drop=True,
    inplace=True
)

# =====================================================
# SIMPAN KE SQLITE
# =====================================================

print("\nMenyimpan Database...")

conn = sqlite3.connect(database_file)

df.to_sql(
    "stok",
    conn,
    if_exists="replace",
    index=False
)

# =====================================================
# MEMBUAT INDEX
# (Agar pencarian jauh lebih cepat)
# =====================================================

cursor = conn.cursor()

cursor.execute("""
CREATE INDEX IF NOT EXISTS idx_item_code
ON stok(item_code)
""")

cursor.execute("""
CREATE INDEX IF NOT EXISTS idx_item_name
ON stok(item_name)
""")

conn.commit()

# =====================================================
# CEK HASIL DATABASE
# =====================================================

print("\nStruktur Database")

cursor.execute("""
PRAGMA table_info(stok)
""")

for row in cursor.fetchall():

    print(row[1])

print("\nJumlah Kolom :", len(df.columns))

print("Jumlah Item  :", len(df))

print("\n5 Data Pertama")

print(df.head())

print("\n5 Data Terakhir")

print(df.tail())

# =====================================================
# INFORMASI GUDANG
# =====================================================

print("\nDaftar Gudang")

gudang = []

for col in df.columns:

    if col.startswith("gd_"):

        gudang.append(col)

for x in gudang:

    print("-", x)

print("\nJumlah Gudang :", len(gudang))

# =====================================================
# SAMPLE ITC
# =====================================================

print("\nContoh Data ITC")

sample = df[
    df["itc"] != ""
]

if len(sample) > 0:

    print(
        sample[
            [
                "item_code",
                "itc"
            ]
        ].head(10)
    )

else:

    print("Tidak ada data ITC.")

# =====================================================
# TUTUP DATABASE
# =====================================================

conn.close()

# =====================================================
# SELESAI
# =====================================================

print("\n" + "=" * 70)
print("IMPORT DATABASE BERHASIL")
print("=" * 70)

print("File Excel")
print(stock_file)

print("\nFile ITC")
print(itc_file)

print("\nDatabase")
print(database_file)

print("\nTotal Item")
print(len(df))

print("\nTotal Gudang")
print(len(gudang))

print("=" * 70)

print("\nSIAP DIGUNAKAN OLEH FLASK")