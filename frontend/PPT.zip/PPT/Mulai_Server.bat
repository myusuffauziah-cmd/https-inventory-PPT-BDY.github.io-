@off
cd /d "C:\Users\User\Documents\PPT"
python app.py
pause