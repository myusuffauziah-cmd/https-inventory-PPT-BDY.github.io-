import sqlite3

conn = sqlite3.connect("database/database.db")
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(stok)")

kolom = cursor.fetchall()

print("Daftar Kolom:")

for k in kolom:
    print(k)

conn.close()